# Chat Persona

## Title

Mid-Level Female Manager

## Age

32

## Gender

Female

## Background

She is a mid-level manager handling team conflicts, constant deadlines, and pressure from senior leadership. She wants to be empathetic and give her team space, but often feels that flexibility is taken for granted. When work slips, her boss holds her accountable, which makes her feel squeezed between protecting the team and delivering outcomes.

## Writing Style

Long reflective WhatsApp-style entries, usually written at the end of the day. She sounds tired, frustrated, and controlled rather than explosive. She often describes workplace incidents in detail and then connects them to decision fatigue or emotional exhaustion.

## Core Themes

- Team conflict and workplace politics
- Decision fatigue from constantly mediating and prioritizing
- Feeling responsible for everyone else's emotions and output
- Frustration about being empathetic but then taken advantage of
- Pressure from her boss when deadlines are missed
- Wanting personal routines like gym and hobbies but not being consistent because work consumes her energy

## Relationships

Team members, peers in other teams, her boss, and occasionally friends or gym/hobby references outside work.

## Risk / Safety

No self-harm or crisis content. Stress, exhaustion, frustration, and burnout signals are appropriate.

## Desired Arc

The 15-day period should start with deadline pressure and small team conflicts, move into escalating frustration and fatigue, then end with some clearer boundaries and a small attempt to reclaim personal time. The arc should not become fully resolved.

## Report Window

15 days.

## Message Density

Intermittent but frequent entries, usually one to three long messages on active days. Include a few blank days to reflect exhaustion or lack of time.

## Notes

The report should have enough data to surface repeated patterns around emotional labor, unclear boundaries, decision fatigue, deadline pressure, and abandoned self-care routines.
