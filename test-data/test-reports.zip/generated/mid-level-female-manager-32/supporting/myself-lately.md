# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 11 of 15

11 of 15 days logged. You documented managing team conflict, changes to gym plans, immediate message replies, and balancing work with personal time.

## Patterns you kept recording
- Gym scheduling challenges — On April 23 and May 3, you wrote about rescheduling or postponing gym time due to work, including 'planned to go to the gym after work, but by 7 pm I was just staring at my laptop' and 'I blocked 45 minutes for the gym today and then moved it twice because of calls.'
- Absorbing team stress — On April 22, April 29, and May 4, you described 'managing stress between team members over a deliverable', 'trying to prevent the conversation from becoming personal', and 'asked each person to name their actual blocker.'

## Moments worth noticing
- May 4 — You wrote 'I tried something different today and asked each person to name their actual blocker.' You also noted it made the meeting 'less emotional and more concrete.'
- May 6 — You wrote 'I asked one person to come back with options instead of giving them the answer.'

## Worth flagging
- 'Tired' and 'exhausted' entries — You recorded feeling 'tired' or 'exhausted' on April 22, April 25, May 2, and April 29, including 'By the end of the day I feel tired in a way that sleep does not immediately fix.'
- 'Frustrated' and 'resentful' — You recorded 'frustrated' on May 2 and May 3 and 'resentful' on April 25.
