# SessionBridge 15-Day Brief

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 11 of 15

## Recorded vocabulary
| Word | Times | Used when |
|---|---|---|
| tired | 5 | absorbing everyone else's stress (Apr 22); sleep does not immediately fix (Apr 22); translating messy human situations (Apr 25); leadership review already exhausted (Apr 29); system look smoother than it is (May 2) |
| irritated | 1 | multiple small escalations in the morning (Apr 23) |
| annoyed | 1 | preoccupied with work deadlines (Apr 27) |
| scared | 1 | decision fatigue becoming real (Apr 30) |
| frustrated | 2 | feedback to be firmer with team (May 2); exercise blocked by work calls (May 3) |
| uncomfortable | 1 | direct communication about blockers (May 4) |
| helpless | 1 | direct communication about blockers (May 4) |

## Ongoing themes
- tiredness and work stress show up most days (5 days)
- exercise or gym plans postponed for work (2 days)

## Open questions
No internal questions recorded in this window.

## Decisions & options considered
- May 3 — I blocked 45 minutes for the gym today and then moved it twice because of calls.
- May 4 — I asked each person to name their actual blocker instead of letting the discussion stay vague.
- May 6 — I asked one person to come back with options instead of giving them the answer.

## Appendix · Daily log
### April 22
- Absorbing everyone else's stress.
- Deadline did not move; boss asked why work was not done.
- Tired in a way that sleep does not fix.

### April 23
- Three separate escalations, each needing a decision.
- Planned gym after work postponed due to work.

### April 25
- Team member requested more time because overwhelmed.
- Tired of translating messy human situations.

### April 26
- Peer implied management style is too accommodating.

### April 27
- Saturday morning plans overtaken by thoughts of Monday's deadline.

### April 29
- Already exhausted before joining leadership review.

### April 30
- Answered almost every message immediately.
- Decision fatigue becoming real.

### May 2
- Boss gave feedback to be firmer with team.
- Tired of making the system look smoother than it is.

### May 3
- Gym time blocked but moved twice due to calls.

### May 4
- Asked each person to name their actual blocker.

### May 6
- Asked one person to come back with options instead of an answer.
