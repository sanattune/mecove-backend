# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 9 of 15

9 of 15 days logged. Entries cluster around leaving a stable job, financial consideration of business risks, and conversations with family about independence.

## Patterns you kept recording
- Ruminating on leaving job — You wrote about the idea of leaving your current job across at least six entries (April 22, April 24, April 26, April 28, May 1, May 6), with quotes like "the first honest thought I have had in years" and "what if I stay and regret it at 45".
- Family questioning decisions — On April 22, April 24, April 28, and May 4, you logged family members asking questions such as "A friend asked me today if I have completely lost my mind for even thinking about leaving a stable job at this age," and "My parents asked why I cannot just be satisfied."
- Financial uncertainty — Financial concerns and calculations are present on April 24 ("what happens to expenses if the business takes one year to work"), April 29 ("I spent the evening making rough numbers. Savings, monthly expenses, possible runway, worst case"), and May 4.

## Moments worth noticing
- May 3 — You wrote, "I spoke to someone who runs a niche consulting practice and he said he did not quit overnight, he built it slowly on the side," and, "Maybe I have been thinking only in extremes."
- May 6 — You stated, "I am not ready to resign tomorrow. Saying that out loud feels disappointing and sensible at the same time," and considered, "Maybe the next step is to test one business idea seriously for 90 days while staying employed."

## Worth flagging
- 'Scared' and 'tired' language — On April 24 and April 26 you used the words "scared" and "afraid" (April 24: "cannot tell if I am being realistic or just afraid."), and on May 3 you wrote, "I am so tired of waiting for permission from circumstances."
- Uncertainty across the window — Expressions of not knowing what is realistic or right recur on April 24 ("cannot tell if I am being realistic or just afraid."), April 26 ("what if I stay and regret it at 45, and then what if I leave and regret it in six months."), and May 1 ("I keep swinging between these two fears.")
