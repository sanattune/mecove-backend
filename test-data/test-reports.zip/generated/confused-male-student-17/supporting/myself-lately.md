# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 12 of 15

You logged 12 of 15 days, focusing mostly on board exam preparation, family comparisons, study planning, and recurring fear about the future.

## Patterns you kept recording
- Comparisons to siblings — On April 24 you wrote "I started comparing myself with him too because he sounds so sorted now" and on April 27 "I compare my present self with their present selves, not even their 17 year old selves."
- Study plan struggles — On April 26 you wrote "I tried making a full study plan today and it looked good on paper but I could not follow it properly" and on May 5 "Today I revised less than planned but I did not collapse completely after missing the target."
- Family pressure moments — On April 30 you wrote "My father got angry today and said I am wasting time by overthinking instead of deciding something."

## Moments worth noticing
- April 29 — "There was a short moment in the afternoon where I understood a topic properly and actually felt capable."
- May 6 — "The fear feels slightly less absolute than it did a few days ago."

## Worth flagging
- Scared or fearful (5+ days) — You used "scared" or "fearful" on April 22, April 23, April 26, April 30, and May 6.
- Disappearing thoughts, tired — On April 30 you wrote "For some time tonight I honestly felt like disappearing because everything seems so difficult and I am tired of feeling scared all the time."
- Frequent sibling comparison — Comparison with siblings appears on at least April 24 and April 27.
