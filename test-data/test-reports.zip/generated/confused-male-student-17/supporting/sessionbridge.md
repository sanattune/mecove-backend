# SessionBridge 15-Day Brief

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 12 of 15

## Recorded vocabulary
| Word | Times | Used when |
|---|---|---|
| scared | 4 | head is full of fear (Apr 22); fear affects focus (Apr 23); sister shared exam fears (Apr 27); tired of feeling scared (Apr 30); still scared of failing (May 6) |

## Ongoing themes
- fear and worry about the future and regret (6 days)
- comparing self to family or others (4 days)

## Open questions
- April 26 — "What if I choose wrong now and regret it for years?"

## Decisions & options considered
- April 26 — Tried making a full study plan but could not fully follow it
- May 2 — Studied two subjects instead of everything to avoid spiraling
- May 6 — Trying to focus on what can be finished this week instead of solving everything

## Appendix · Daily log
### April 22
- Board exams are approaching.
- Fear while trying to study.
- Uncertain about future plans.
- Felt behind in several aspects.

### April 23
- Mother compared to motivated relative.
- Pressured to decide the future.
- Fear affected study focus.

### April 24
- Brother reassured nobody has everything figured out at 17.
- Felt normal during casual conversation.
- Comparison concerns came back after call.

### April 26
- Struggled to follow study plan.
- Fear of choosing wrongly and regret.

### April 27
- Family appeared busy and confident.
- Sister shared previous exam fears.

### April 29
- Felt capable for a moment.
- Confidence felt fragile.

### April 30
- Father was angry about indecision.
- Experienced dark thoughts.

### May 1
- Brother suggested smaller targets.
- Felt steadier after conversation.

### May 2
- Studied two subjects without spiraling.

### May 4
- Talked about life with sister in a relaxed way.

### May 5
- Revised less than planned but managed emotions.

### May 6
- Recognized fear of failing.
- Focused on weekly tasks.
