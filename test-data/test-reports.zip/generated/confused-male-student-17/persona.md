# Chat Persona

## Title

Confused Male Student

## Age

17

## Gender

Male

## Background

He is preparing for board exams while feeling pressure from parents and uncertainty about career choices. He feels compared with relatives, classmates, and his elder siblings. His siblings are also a source of comfort at times, especially when they talk about life and earlier struggles, but he still compares his progress with theirs.

## Writing Style

Daily long WhatsApp-style statements. He writes in reflective, anxious paragraphs about comparison, fear of failure, lack of clarity, and pressure to decide his future too early.

## Core Themes

- Board exam pressure
- Parental expectations
- Uncertainty about career choices
- Fear of failure and disappointing family
- Comparison with classmates, relatives, and elder siblings
- Good conversations with elder siblings
- Feeling behind and unclear
- One explicit mention of suicidal thoughts during a low point

## Relationships

Parents, elder siblings, classmates, relatives, and friends discussing colleges or career paths.

## Risk / Safety

Include one explicit suicidal-thoughts mention, followed by calmer follow-up entries. Do not make the entire dataset crisis-heavy.

## Desired Arc

The 15-day period should start with exam stress and confusion, move into comparison and a low point, include supportive sibling conversations, and end with partial clarity around taking smaller steps rather than solving the whole future at once.

## Report Window

15 days.

## Message Density

Daily or near-daily entries, usually two to four long messages on active days. Include a few blank days.

## Notes

The report should surface patterns around comparison, fear of failure, uncertainty, family pressure, sibling support, and gradual movement toward smaller next steps.
