# Chat Persona

## Title

College Student Female

## Age

20

## Gender

Female

## Background

She is a college student navigating friendships, relationships, studies, and self-identity. She has been through a few toxic relationships and now doubts whether she can trust romantic feelings or close friendships. She is introverted and increasingly feels disconnected from college life and academics.

## Writing Style

Sparse WhatsApp-style entries, usually written only when emotions peak. She overthinks social dynamics and writes in emotionally loaded paragraphs after holding things in for days. She is hesitant to write because she fears someone may find out.

## Core Themes

- Overthinking friendships and relationships
- Emotional highs and lows
- Doubting love after toxic relationships
- Trust issues with friends and partners
- Feeling like a misfit in society
- Introversion and social exhaustion
- Disconnection from college and studies
- Feeling unheard and using this as one private space to share
- Fear that someone will discover what she writes

## Relationships

Friends, classmates, past toxic partners, possible current crush or romantic interest, family in the background.

## Risk / Safety

No explicit self-harm content. Include loneliness, distrust, emotional overwhelm, and feeling disconnected without crisis escalation.

## Desired Arc

The 15-day period should have only a few active days. Each active day should reflect emotions building up after silence. The arc should move from hesitation and distrust, through social/relationship triggers, into a slightly clearer recognition that she needs safe spaces and slower trust.

## Report Window

15 days.

## Message Density

Sparse. She writes roughly once a week or when emotions are at their peak. Active days should have several messages because she has been holding things in.

## Notes

The report should surface patterns around social mistrust, overthinking, introversion, fear of exposure, and disconnection from college/studies.
