# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 4 of 15

4 of 15 days logged. Entries cluster around exclusion in social settings, mistrust in relationships, repeated concerns about privacy, and skipping activities.

## Patterns you kept recording
- Mistrust in social interactions — You wrote about mistrust or difficulty trusting others on April 22, May 3, and May 6, including: "If someone is kind, I wonder what they want." and "I want connection but I do not trust it when it comes close."
- Feeling disconnected from groups — Across entries on April 22 and April 27, you described feelings of not belonging: "I feel like I do not belong in relationships, friendships, college, anywhere." and "I keep feeling like I am standing slightly outside everything."
- Worry about privacy of writing — On April 22 you wrote "I almost did not write here because even this feels unsafe sometimes" and on May 6, "I kept checking if I should delete what I wrote here."

## Moments worth noticing
- May 6 — You wrote: "Today I skipped a college event because the thought of smiling and acting casual felt impossible." and "writing this made it a little clearer that I am not lazy exactly."
- May 3 — You noted: "I keep asking myself if I even know how to fall in love without losing myself." and "I also feel guilty because this person may be genuinely nice and I am already treating the whole thing like danger."

## Worth flagging
- 'Tired' and 'exhausting' language — On April 22 you wrote "I am tired of overthinking every message and every face expression," and on May 6 you used the word "exhausting."
- Mistrust appearing on 3 days — Trust-related concerns are present on April 22, May 3, and May 6, including "If someone is kind, I wonder what they want." and "I want connection but I do not trust it when it comes close."
