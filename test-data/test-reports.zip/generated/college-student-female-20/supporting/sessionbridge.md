# SessionBridge 15-Day Brief

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 4 of 15

## Recorded vocabulary
| Word | Times | Used when |
|---|---|---|
| tired | 1 | tired of overthinking every message and face expression (Apr 22) |
| excluded | 1 | felt excluded from a group plan (Apr 27) |
| scared | 2 | treating new relationships like danger (May 3); skipped a college event, smiling felt impossible (May 6) |
| guilty | 1 | guilty for treating a genuinely nice person with suspicion (May 3) |

## Ongoing themes
- feeling disconnected from college and social life (2 days)

## Open questions
No internal questions recorded in this window.

## Decisions & options considered
No decisions or options named in this window.

## Appendix · Daily log
### April 22
- "I almost did not write here because even this feels unsafe sometimes"
- "College feels loud even when nothing is happening."
- "If someone is kind, I wonder what they want."
- "I am tired of overthinking every message and every face expression."

### April 27
- "They made a plan in front of me and then said oh you can come if you want"
- "I came back to my room and did not study at all."
- "I feel like I do not belong in relationships, friendships, college, anywhere."
- "I hate that I am writing so much now after not writing for days, but when it comes out it all comes together."

### May 3
- "I feel guilty because this person may be genuinely nice and I am already treating the whole thing like danger."
- "I have not submitted one assignment and I barely care right now."

### May 6
- "Today I skipped a college event because the thought of smiling and acting casual felt impossible."
- "I think I want connection but I do not trust it when it comes close."
- "Maybe trusting slowly is still trust, even if it looks small from outside."
- "I still feel disconnected from studies and college, but writing this made it a little clearer that I am not lazy exactly."
