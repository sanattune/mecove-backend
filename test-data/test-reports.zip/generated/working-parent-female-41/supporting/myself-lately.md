# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 11 of 15

11 out of 15 days include logs about work, home, and personal challenges, with records of switching roles, judgments about appearance, and pressure from expectations.

## Patterns you kept recording
- Switching roles at home and work — On April 22, April 25, April 26, April 28, April 29, and May 2, you described managing tasks in both office and home, including "I kept moving from packing lunch to office calls to checking on my child to finishing one pending deck" (April 22) and "I am never fully absent from home and never fully present at work, and both places still expect full performance" (April 29).
- Comments about your appearance — On April 23 and May 1, you wrote, "Someone at home made a comment in the morning about how I dress now that I go to office" and "Today someone commented again about my clothes, saying office has changed me."
- Pressure to stay positive — On April 22 and April 25, you noted expectations to stay positive: "I feel stretched like I am being pulled from both sides, and somehow I am expected to smile because I chose this job" (April 22) and "I said yes because I did not want to sound difficult, but I also had to rush home and help with homework" (April 25).

## Moments worth noticing
- May 5 — You wrote, "I told my spouse today that I need more help in the mornings," and "Maybe I have been waiting for someone to notice, but maybe I also need to stop hiding how much I am carrying."
- May 6 — You wrote, "Tonight I am tired again, but a little less angry. Not because the situation changed fully, but because I can see more clearly that I am not weak for feeling stretched."

## Worth flagging
- "Tired" and "stretched" recurrence — You used 'tired' on April 25 and May 6, and 'stretched' on April 22 and May 6: "I feel stretched like I am being pulled from both sides" (April 22), "Tonight I am tired again ... I am not weak for feeling stretched" (May 6).
- Judged on three dates — Judgment from others about work, independence, or appearance is mentioned on April 23 ("Someone at home made a comment in the morning about how I dress now that I go to office"), April 28 ("It feels like carrying two full lives and being judged in both"), and May 1 ("Today someone commented again about my clothes, saying office has changed me").
- Invisible May 4 and April 25 — You wrote about feeling unnoticed on May 4: "Today was one of those days where I felt invisible." This is also referenced when you noted on April 25, "I am writing this now because otherwise the day will end without anyone knowing how heavy it felt."
