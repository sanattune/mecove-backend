# SessionBridge 15-Day Brief

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 11 of 15

## Recorded vocabulary
| Word | Times | Used when |
|---|---|---|
| stretched | 2 | managing responsibilities at work and home (Apr 22); not weak for feeling stretched (May 6) |
| cried | 1 | cried in the cab due to emotions about child (Apr 23) |
| hate | 2 | expected to be flexible everywhere (Apr 25); hate missing small moments (May 2) |
| guilt | 2 | guilt about prioritizing work questions (Apr 26); hate missing small moments due to work pressure (May 2) |
| fear | 1 | fear child will remember me as always leaving or tired (Apr 26) |
| angry | 3 | anger after relative's comment (Apr 28); embarrassed and angry at clothing comment (May 1); tired but less angry, more clarity (May 6) |
| embarrassed | 1 | embarrassed and angry at clothing comment (May 1) |
| tense | 1 | still in deadline mode at home (May 2) |
| invisible | 1 | felt invisible despite meeting responsibilities (May 4) |
| tired | 2 | remembered as always leaving or tired (Apr 26); tired again, but a little less angry (May 6) |
| worried | 1 | tired, angry, and worried (May 6) |

## Ongoing themes
- balancing responsibilities at home and work (5 days)
- comments and emotions about appearance (2 days)

## Open questions
No internal questions recorded in this window.

## Decisions & options considered
- May 5 — told my spouse I need more help in the mornings
- May 5 — attempted dividing some tasks at home

## Appendix · Daily log
### April 22
- managing responsibilities at work and home, feeling stretched
- moved from packing lunch to office calls to checking on child to finishing pending deck
- deadline missed by two hours
- expected to smile despite challenges

### April 23
- comment about dressing lingered
- cried in cab due to child's sleepiness
- repeated checks about child's meals

### April 25
- accepted extra review at work
- expected to be flexible at work, home, with relatives, with child
- finished chores and emails late at night

### April 26
- felt guilt about prioritizing work
- worried about child's memory of working habits
- manager discussed timeline slipping

### April 28
- Sunday filled with chores
- anger after relative's comment about working mothers and independence
- felt like carrying two full lives and being judged

### April 29
- received unsettling message during meeting
- difficult to balance attention between home and work

### May 1
- comments on clothing led to embarrassment and anger
- clothing choices prompted scrutiny
- felt subject to unsolicited commentary

### May 2
- deadline pressures impacted interactions at home
- missed small family moments due to work stress

### May 4
- met responsibilities but felt invisible
- missed items get noticed

### May 5
- asked for help with morning routines
- discussed dividing tasks at home
- expressed load and desire for acknowledgment

### May 6
- tired again, but less angry
- real work at home and at office landing at same time
