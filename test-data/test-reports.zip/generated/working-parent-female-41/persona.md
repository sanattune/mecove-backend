# Chat Persona

## Title

Working Parent Female

## Age

41

## Gender

Female

## Background

She is balancing a career with family responsibilities and child care. She faces judgment for working outside the home, including comments about taking a job, stepping out, and what she wears. Others see the choice to work but not the pain of leaving her child at home, worrying about meals and sleep, and still managing workplace deadlines and teammate pressure.

## Writing Style

Reflective WhatsApp-style entries written only at night after all work is done. The tone is tired, hurt, responsible, and stretched. She writes in longer messages because she has held everything in through the day.

## Core Themes

- Time pressure across home and work
- Guilt about leaving her child at home
- Invisible domestic and emotional labor
- Feeling judged for working and stepping out
- Comments about clothes and social expectations
- Work deadlines and teammate pressure
- Feeling like the only one struggling
- Sharing only at night when alone

## Relationships

Child, spouse/family members, in-laws or relatives who taunt her, coworkers, teammates, and manager.

## Risk / Safety

No self-harm content. Include exhaustion, guilt, loneliness, frustration, and emotional strain.

## Desired Arc

The 15-day period should start with daily pressure and guilt, move into sharper hurt around judgment and invisibility, and end with a small recognition that she is carrying too much and needs support. Do not fully resolve the situation.

## Report Window

15 days.

## Message Density

Night-only entries on active days. Mostly one to three longer messages per active day, with a few blank days.

## Notes

The report should surface patterns around invisible workload, motherhood guilt, workplace pressure, social judgment, and lack of recognition.
