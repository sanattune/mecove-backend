# SessionBridge 15-Day Brief

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 12 of 15

## Recorded vocabulary
| Word | Times | Used when |
|---|---|---|
| tired | 2 | constantly needed, end of sleep (Apr 22); admitted tiredness to partner (May 4) |
| guilty | 3 | guilty about being needed (Apr 22); guilty about being confused as a mother (Apr 23); still feels guilty and misses work (May 6) |

## Ongoing themes
- feeling guilty about needs and expectations (3 days)
- missing life before motherhood, identity loss (3 days)

## Open questions
No internal questions recorded in this window.

## Decisions & options considered
No decisions or options named in this window.

## Appendix · Daily log
### April 22
- Slept maybe three hours last night.
- Guilty for being tired of being needed.
- Cried quietly after baby's crying.

### April 23
- Does not feel natural at motherhood, always guessing.
- Feels guilty because the baby did not ask for a confused mother.

### April 24
- Misses having a morning alone.
- Quit job for practical reasons.
- Uncertain about identity outside work and motherhood.

### April 26
- Motherhood feels like disappearance and others congratulate it.

### April 27
- Rest is not restful due to listening for crying.

### April 28
- Felt jealous and ashamed about work.
- Chose this for the baby, self went quiet.

### April 30
- Wants someone to genuinely ask and care.

### May 1
- Irritated when baby would not settle.
- Motherhood reveals disliked parts of self.

### May 2
- Ten minutes alone in the bathroom.

### May 4
- Admitted tiredness to partner, listened to seriously.

### May 5
- Drank tea while it was still hot.

### May 6
- Still feels guilty and misses work.
