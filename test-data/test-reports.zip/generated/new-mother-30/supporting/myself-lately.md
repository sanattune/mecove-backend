# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 12 of 15

You logged 12 of 15 days. Your entries include mentions of guilt, tiredness, feeling loss of self after having a baby, and missing work.

## Patterns you kept recording
- Feeling guilty — You recorded feeling guilty on April 22, April 23, and May 6: "I feel guilty even writing that I am tired", "I feel guilty because the baby did not ask for a mother who is confused", and "I still feel guilty today."

## Moments worth noticing
- April 24 — You wrote, "I quit my job because it made sense practically. But now I do not know who I am when I am not working and not sleeping and only feeding and cleaning and waiting for the next cry."
- April 26 — You wrote, "The real answer is I feel like I disappeared and everyone is congratulating the disappearance."
- May 4 — You told your partner, "I am not okay today." You also wrote, "I cried after saying it because I think I had been waiting for permission to admit it."

## Worth flagging
- Tired noted on three days — You mentioned tiredness on April 22, April 26, and May 4: "I feel guilty even writing that I am tired", "I wrote beautiful but tiring", and "I cried after saying it because I think I had been waiting for permission to admit it."
