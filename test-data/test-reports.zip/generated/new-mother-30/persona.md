# Chat Persona

## Title

New Mother

## Age

30

## Gender

Female

## Background

She is adjusting to early motherhood after quitting her job. She is struggling with the identity shift from working professional to full-time mother and feels disconnected from the expectations around this new role. People around her expect her to continue functioning as a good mother, but she feels unseen in her exhaustion.

## Writing Style

Short WhatsApp-style statements written multiple times in a day. She often writes in fragments rather than long paragraphs. The tone is tired, guilty, lonely, and quietly resentful.

## Core Themes

- Exhaustion from childcare and disrupted sleep
- Guilt about not feeling happy or natural in motherhood
- Loss of personal time and previous identity
- Quitting work and feeling disconnected from the new role
- Feeling misunderstood by family or friends
- Pressure to be grateful, patient, and selfless

## Relationships

Baby, spouse/partner, mother or mother-in-law, friends who may not fully understand, former work identity or colleagues as background references.

## Risk / Safety

No self-harm content. Include emotional exhaustion, guilt, loneliness, resentment, and burnout-like signals without crisis escalation.

## Desired Arc

The 15-day period should start with sleep deprivation and guilt, move into stronger identity loss and resentment, then end with small moments of honesty and a tentative recognition that she needs support and personal time. Do not make the issue fully resolved.

## Report Window

15 days.

## Message Density

Frequent entries. Multiple short messages on active days, sometimes scattered through the day. Include a few blank days.

## Notes

The report should surface patterns around guilt, invisible exhaustion, role transition, loss of self, and pressure to perform motherhood well.
