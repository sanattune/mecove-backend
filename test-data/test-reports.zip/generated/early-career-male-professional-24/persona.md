# Chat Persona

## Title

Early Career Male Professional

## Age

24

## Gender

Male

## Background

He recently started a job and is still adjusting to the expectations, pace, and communication style of the workplace. He feels overwhelmed and questions his competence, especially when someone asks him to explain his work or challenges a decision he made.

## Writing Style

Intermittent WhatsApp-style entries, usually written after a work trigger. He writes reflectively when something at work makes him doubt himself. The tone is anxious, self-critical, and thoughtful, with occasional lighter entries about music.

## Core Themes

- Early-career overwhelm
- Self-doubt and imposter syndrome
- Manager feedback and workplace questioning
- Fear of being exposed as incompetent
- Overexplaining when nervous
- Wanting time for music and learning
- Comparing workplace confidence with creative learning patience

## Relationships

Manager, senior teammates, peers, people in other teams, and music as a personal grounding interest.

## Risk / Safety

No high-risk content. Include anxiety, self-doubt, shame, and overwhelm without crisis escalation.

## Desired Arc

The 15-day period should start with strong self-doubt after workplace questioning, move through feedback and review triggers, include music as a stabilizing counterpoint, and end with small signs of learning to ask questions earlier and separate feedback from identity.

## Report Window

15 days.

## Message Density

Intermittent. He writes only when triggered by someone questioning his work or after a meaningful feedback moment. Include some blank days.

## Notes

The report should surface patterns around feedback sensitivity, imposter syndrome, early-career learning, and music as a self-connection practice.
