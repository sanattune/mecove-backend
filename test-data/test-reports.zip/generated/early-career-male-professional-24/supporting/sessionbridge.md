# SessionBridge 15-Day Brief

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 11 of 15

## Recorded vocabulary
| Word | Times | Used when |
|---|---|---|
| scared | 2 | scared about pretending to understand (Apr 22); scared questions will reveal not good enough (May 4) |
| exposed | 2 | felt exposed by workplace questions (Apr 22); felt exposed during reviews (Apr 26) |
| nervous | 1 | nervous making update longer in standup (Apr 24) |
| embarrassed | 1 | embarrassed by concise answers coming easy to others (Apr 24) |
| tiring | 1 | job feels like a final exam every day (Apr 24) |
| defensive | 1 | defensive after timeline questioned (Apr 28) |
| exhausted | 1 | stayed late and felt exhausted (Apr 28) |
| panicking | 1 | panicking after work feedback (Apr 28) |
| confused | 1 | confused during workplace interactions (Apr 22) |

## Ongoing themes
- fear of not being competent at work (2 days)
- feedback quickly becomes about personal worth (2 days)

## Open questions
No internal questions recorded in this window.

## Decisions & options considered
- May 1 — "Maybe I should keep one evening a week for music properly."

## Appendix · Daily log
### April 22
- Manager asked about task approach.
- Scared about pretending to understand.
- The question made me feel exposed.

### April 24
- Made update explanation longer in standup because of nervousness.
- Embarrassed because concise answers seem natural for others.
- Job feels like a final exam every day.

### April 25
- Picked up guitar for 20 minutes.
- Music felt like a part outside work performance.

### April 26
- Received reasonable feedback on pull request.
- Missed an edge case in work.
- Felt exposed during reviews.

### April 28
- Defensive after timeline questioned by another team.
- Stayed late and felt exhausted.

### April 30
- Manager asked for clearer tradeoffs next time.
- Feedback quickly becomes identity.

### May 1
- Listened to old college songs and enjoyed figuring out melodies.
- Maybe keep one evening a week for music.

### May 2
- Estimate challenged in meeting.
- Thought about doubts about being hired.

### May 4
- Manager suggested asking for clarification earlier.
- Waiting too long with questions out of fear of not being good enough.

### May 5
- Practiced guitar and attempted challenging song.
- Wished for music patience at work.

### May 6
- Received review with suggestions.
- Tried to separate comments from identity.
