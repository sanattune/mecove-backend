# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 11 of 15

You logged 11 of 15 days, writing about work feedback, times you played or listened to music, and workplace situations that led to nervousness or feeling exposed.

## Patterns you kept recording
- Work feedback and identity — On April 30 and May 6, you wrote "I hate how quickly feedback becomes identity for me" and "I tried to separate the comment from my whole identity and just wrote down what needed to change."
- Music activities repeated — You engaged with music on April 25, May 1, and May 5: "I picked up my guitar for 20 minutes today after a long time", "I listened to some old songs I used to practice in college", and "I practiced guitar tonight and tried a song I used to avoid because the chord changes were hard."
- Feeling exposed at work — On April 22, April 26, and May 2, you described feeling exposed or self-conscious about mistakes in front of others.

## Moments worth noticing
- May 6 — You wrote, "I tried to separate the comment from my whole identity and just wrote down what needed to change."
- April 25 — You wrote, "I picked up my guitar for 20 minutes today after a long time" and "I want to protect that somehow instead of letting office stress eat every evening."

## Worth flagging
- "Exposed" and "exhausted" words — On April 22 and April 26, you used the word "exposed"; on April 28, you wrote "I stayed late again and now I am exhausted."
- Work-related stress recurrence — On five days (April 22, April 24, April 26, April 28, May 2), you wrote "I am scared that I am just good at pretending I understand things," "my mind treats it like a final exam every day," "I turn it into a character flaw," and "I just hate the public moment where I realize I missed something and everyone else realizes it too."
