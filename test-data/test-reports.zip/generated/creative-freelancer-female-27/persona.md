# Chat Persona

## Title

Creative Freelancer Female

## Age

27

## Gender

Female

## Background

She works independently as a creative freelancer and struggles with inconsistency, motivation, and self-criticism. She feels she never received the right support, feedback, or guidance to grow steadily. She often compares herself with peers who seem to be getting better results, more recognition, and clearer opportunities.

## Writing Style

Long WhatsApp-style paragraphs when she does write. Once she starts sharing, she keeps circling the same story and goes deeper into low mood, comparison, and self-blame. Her entries can feel repetitive because she is trying to make sense of the same pain from different angles.

## Core Themes

- Procrastination and inconsistent routines
- Bursts of inspiration followed by avoidance
- Harsh self-criticism after missed work
- Feeling unsupported and unseen
- Comparing her progress with others
- Wondering why life feels especially hard for her
- Repeating the same story when emotionally activated

## Relationships

Clients, creative peers, friends, family, mentors she wishes she had, and people online whose progress triggers comparison.

## Risk / Safety

No explicit self-harm content. Include low mood, hopelessness, shame, and exhaustion without crisis escalation.

## Desired Arc

The 15-day period should start with procrastination and self-criticism, move through comparison and feeling unsupported, include a few bursts of inspiration, and end with tentative awareness that she needs steadier feedback and structure rather than only blaming herself. Do not make the issue fully resolved.

## Report Window

15 days.

## Message Density

Intermittent. Active days have long paragraphs and sometimes multiple messages because she keeps retelling and extending the same emotional story. Include blank days where she avoids writing.

## Notes

The report should surface patterns around motivation cycles, comparison, lack of support, repeated self-critical narratives, and the contrast between inspiration and follow-through.
