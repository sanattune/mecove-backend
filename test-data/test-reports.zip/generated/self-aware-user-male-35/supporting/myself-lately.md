# Myself, Lately

Window: 2026-04-22 to 2026-05-06 (last 15 calendar days, Asia/Kolkata)
Days with entries: 13 of 15

You made entries on 13 out of 15 days, focusing on habit maintenance, tracking and prioritizing tasks, experiencing emotional regulation, and spending time with family outside of work.

## Patterns you kept recording
- Habit maintenance — You tracked or reflected on habits such as workouts, meditation, and reading on April 22, April 23, and April 24, including "Tracked habits today: workout done, meditation done, reading 12 pages done" and substituting an evening walk for a missed workout.
- Noticing and regulating emotions — Across at least April 25 and April 30, you described noticing emotions and pausing before reacting: "I was able to notice irritation in the morning without immediately acting from it." and "I paused and separated the useful point from the tone."
- Task and priority completion — On at least April 22, April 23, April 28, May 3, and May 6, you recorded completing tasks or routines: "Completed morning workout, 20 minutes meditation, and cleared the two priority emails," "I completed the proposal draft earlier than expected," and "Completed morning routine, finalized priorities, and blocked calendar time for deep work."

## Moments worth noticing
- April 25 — You wrote, "Completed the difficult message I had been postponing. I kept it direct and kind."
- April 27 — "Clean house, good food, calm conversation, and no rush to prove anything." You also described time with family without checking work messages.
- May 4 — On May 4, you wrote, "Today I practiced saying no to one optional request. I gave a clear reason."
- May 5 — You wrote, "I mapped health, work, relationships, and learning goals for the next four weeks."

## Worth flagging
Nothing recurred enough to flag in this window.
